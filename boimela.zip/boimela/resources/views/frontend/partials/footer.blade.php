<footer class="footer-bottom">
  <p class="text-center">&copy; 2021 All rights reserved | Online Ekushe Boimela</p>
</footer>
