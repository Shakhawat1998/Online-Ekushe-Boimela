@extends('frontend.layouts.master')

@section('content')
  <div class='container margin-top-20'>
    <h2 align="center">Contact Page</h2>
    <p align="center">Saiful Islam Bhuiyan<br>Email:u1704073@student.cuet.ac.bd</p>
    <p align="center">Towfiq Alam Pranto<br>Email:u1704080@student.cuet.ac.bd</p>
    <p align="center">Md Shakhawat Hossain<br>Email:u1704083@student.cuet.ac.bd</p>
  </div>
@endsection
