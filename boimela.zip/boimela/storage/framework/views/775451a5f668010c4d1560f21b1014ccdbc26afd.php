<footer class="footer-bottom">
  <p class="text-center">&copy; 2021 All rights reserved | Online Ekusey Boimela</p>
</footer>
<?php /**PATH C:\xampp\htdocs\Ebook\resources\views/partials/footer.blade.php ENDPATH**/ ?>