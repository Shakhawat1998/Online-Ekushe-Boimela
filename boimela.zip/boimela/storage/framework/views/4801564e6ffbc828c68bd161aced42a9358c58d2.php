<?php $__env->startSection('content'); ?>
  <div class='container margin-top-20'>
    <h2 align="center">Contact Page</h2>
    <p align="center">Saiful Islam Bhuiyan<br>Email:u1704073@student.cuet.ac.bd</p>
    <p align="center">Towfiq Alam Pranto<br>Email:u1704080@student.cuet.ac.bd</p>
    <p align="center">Md Shakhawat Hossain<br>Email:u1704083@student.cuet.ac.bd</p>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\boimela\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>