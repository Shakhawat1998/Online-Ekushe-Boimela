<script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>

<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php /**PATH C:\xampp\htdocs\Ebook\resources\views/frontend/partials/styles.blade.php ENDPATH**/ ?>