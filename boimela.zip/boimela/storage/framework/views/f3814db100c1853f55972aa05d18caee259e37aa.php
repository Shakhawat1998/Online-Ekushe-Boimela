<script src="<?php echo e(asset('js/jquery-3.2.1.slim.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" ></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\boimela\resources\views/frontend/partials/scripts.blade.php ENDPATH**/ ?>