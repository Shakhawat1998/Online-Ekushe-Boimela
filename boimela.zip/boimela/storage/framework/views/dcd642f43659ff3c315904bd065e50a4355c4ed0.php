<footer class="footer-bottom">
  <p class="text-center">&copy; 2021 All rights reserved | Online Ekushe Boimela</p>
</footer>
<?php /**PATH C:\xampp\htdocs\boimela\resources\views/frontend/partials/footer.blade.php ENDPATH**/ ?>