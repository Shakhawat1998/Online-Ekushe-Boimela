<form class="form-inline" action="<?php echo e(route('carts.store')); ?>" method="post">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
  <button type="submit" class="btn btn-warning"><i class="fa fa-plus"></i> Add to cart</button>
</form>
<?php /**PATH C:\xampp\htdocs\Ebook\resources\views/frontend/pages/product/partials/cart-button.blade.php ENDPATH**/ ?>